# NOX Lab v0.8

Home and Research updated for review. Other pages retain v0.7 content.

## Run
Use Node 22.23.1 or newer compatible Node 22 release (see .nvmrc).

```
npm ci
npm run dev
npm run build
npm run export:preview
```

The export command builds the Astro site, then produces ../noxlab-preview-v0.8 with index.html and research.html. Open these files directly; no server is required. Supporting pages are included so navigation works. The Astro production build is in dist/.

## Changes
- Home: introduction, three research themes, three latest publications from the existing collection (year descending; title breaks ties because exact publication dates are unavailable).
- Research: continuous narrative on computational neuroscience, neurotechnology, and sensorimotor and defensive systems. No publication lists, methods lists, diagrams or project catalogue.
- Computational neuroscience: multiscale mechanisms, ascending and descending pathways, modelling, multimodal neural and behavioural analysis, human studies and animal-model data from external collaborators.
- EPIONE: Flavia Mancini’s theory leadership and NOX Lab’s theoretical and computational contribution, linked to the official programme.
- New supplied red NOX logo, restrained red accents, serif headings, readable text widths and mobile navigation.

## Review notes
The logo is the provisional raster extracted from the previous preview; replace public/images/nox-logo.png with the final designer asset when available. Publication metadata and other pages are carried forward, not independently audited. People and Join Us are next-stage work. This is a review package, not a published site.

## Verification
Astro check and production build passed (0 errors, 0 warnings; inherited deprecation hints remain). Browser checks covered narrow-screen menu operation, Home-to-Research navigation and desktop Research layout. Static internal links and assets were checked locally.
