import { readdir, readFile, writeFile, mkdir, cp } from 'node:fs/promises';
import path from 'node:path';
const source = path.resolve('dist');
const target = path.resolve(process.argv[2] || '../noxlab-preview-v0.8');
await mkdir(target, { recursive: true });
const pages = [];
async function walk(dir) {
  for (const item of await readdir(dir, { withFileTypes: true })) {
    const file = path.join(dir, item.name);
    if (item.isDirectory()) await walk(file);
    else if (file.endsWith('.html')) pages.push(path.relative(source, file));
  }
}
await walk(source);
const routes = new Map(pages.map(file => ['/' + file.replace(/index\.html$/, ''), file === 'index.html' ? file : file.replace(/\/index\.html$/, '').replaceAll('/', '-') + '.html']));
for (const file of pages) {
  let html = await readFile(path.join(source, file), 'utf8');
  for (const match of [...html.matchAll(/<script\b[^>]*src="([^\"]+)"[^>]*><\/script>/g)]) {
    if (match[1].startsWith('/')) {
      const js = await readFile(path.join(source, match[1]), 'utf8');
      html = html.replace(match[0], `<script>${js}</script>`);
    }
  }
  html = html.replace(/(href|src)="\/([^\"]*)"/g, (all, attr, value) => {
    const [route, hash] = ('/' + value).split('#');
    const mapped = routes.get(route);
    return `${attr}="${mapped ? mapped + (hash ? '#' + hash : '') : value}"`;
  });
  html = html.replace(/url=\/apply\//gi, 'url=apply.html').replace(/url=\/research\/#sensorimotor-defensive-systems/gi, 'url=research.html#sensorimotor-defensive-systems');
  const name = routes.get('/' + file.replace(/index\.html$/, ''));
  await writeFile(path.join(target, name), html);
}
for (const asset of ['_astro', 'images', 'favicon.svg']) await cp(path.join(source, asset), path.join(target, asset), { recursive: true });
await writeFile(path.join(target, 'README.txt'), 'NOX Lab v0.8 static preview\nOpen index.html or research.html in a browser. No installation needed.\nOther pages are carried forward from v0.7. Logo is the supplied provisional raster asset.\n');
console.log(`Exported ${pages.length} pages to ${target}`);
