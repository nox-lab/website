# Content model

## Research theme

A durable area of scientific capability or application.

Fields: title, short title, kind, summary, order, featured.

`kind` is one of:

- `core` — computational neuroscience or neurotechnology
- `application` — pain or another use domain

## Person

A current or former lab member.

Fields: name, role, order, links, research interests and alumni status.

## Publication

A structured output record.

Fields: title, authors, year, venue, DOI or URL, themes, tags and featured status.

## Future collections

There is currently no dedicated collection for projects, software or datasets. Programme-level detail lives in the prose body of the relevant research theme (see `computational-neuroscience.md` and `neurotechnology.md`) rather than as separate structured records.
