# NOX Lab website design brief

## Core identity

NOX Lab is a computational neuroscience and neurotechnology research group. It develops models and technologies to understand, predict and influence nervous-system function.

Pain is an important application domain, but it does not define the lab.

## Communication hierarchy

1. Computational neuroscience — scientific questions, theory and models.
2. Neurotechnology — tools, biomarkers, interfaces and interventions.
3. Applications — pain and other clinical or real-world domains.

## Audiences

- Prospective researchers and students
- Scientific collaborators
- Funders and institutional partners
- Researchers looking for publications, software or data
- Research participants

## Design principles

- Scientific before promotional
- Computational first
- One strong hero statement, not repeated oversized quotations
- Restrained editorial typography and generous whitespace
- Structured content with relationships between themes, projects, people and outputs
- Accessible, fast and maintainable through Git

## Homepage narrative

1. What NOX Lab is
2. The two core capabilities: computational neuroscience and neurotechnology
3. The scientific questions
4. Selected projects and outputs
5. Applications and translation
6. News, opportunities and contact
