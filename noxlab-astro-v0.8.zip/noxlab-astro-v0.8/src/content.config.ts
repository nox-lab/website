import { defineCollection, reference, z } from 'astro:content';
import { glob } from 'astro/loaders';

const people = defineCollection({
  loader: glob({ pattern: '**/*.{md,mdx}', base: './src/content/people' }),
  schema: z.object({
    name: z.string(),
    role: z.string(),
    group: z.enum(['leadership', 'phd', 'research', 'alumni']).default('research'),
    photo: z.string().optional(),
    photoAlt: z.string().optional(),
    order: z.number().default(99),
    email: z.string().email().optional(),
    orcid: z.string().url().optional(),
    scholar: z.string().url().optional(),
    linkedin: z.string().url().optional(),
    research: z.array(z.string()).default([]),
    alumni: z.boolean().default(false)
  })
});

const research = defineCollection({
  loader: glob({ pattern: '**/*.{md,mdx}', base: './src/content/research' }),
  schema: z.object({
    title: z.string(),
    shortTitle: z.string(),
    kind: z.enum(['core', 'application']),
    summary: z.string(),
    order: z.number(),
    featured: z.boolean().default(true)
  })
});

const publications = defineCollection({
  loader: glob({ pattern: '**/*.{md,mdx}', base: './src/content/publications' }),
  schema: z.object({
    title: z.string(),
    authors: z.array(z.string()),
    year: z.number(),
    venue: z.string(),
    url: z.string().url().optional(),
    doi: z.string().optional(),
    themes: z.array(reference('research')).default([]),
    tags: z.array(z.string()).default([]),
    featured: z.boolean().default(false)
  })
});

export const collections = { people, research, publications };
