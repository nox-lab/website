---
title: "Enhanced behavioural and neural sensitivity to punishments in chronic pain and fatigue"
authors: ["Flavia Mancini", "Pranav Mahajan", "Anna Á. V. Guttesen", "Jakub Onysk", "Ingrid Scholtes", "Nicholas Shenker", "Michael Lee", "Ben Seymour"]
year: 2025
venue: "Brain"
url: "https://doi.org/10.1093/brain/awae408"
doi: "10.1093/brain/awae408"
---
