---
title: "A theory of how pretraining shapes inductive bias in fine-tuning"
authors: ["N. Anguita", "F. Locatello", "A. M. Saxe", "M. Mondelli", "Flavia Mancini", "S. Lippl", "C. Domine"]
year: 2026
venue: "International Conference on Machine Learning"
url: "https://arxiv.org/abs/2602.20062"
---
