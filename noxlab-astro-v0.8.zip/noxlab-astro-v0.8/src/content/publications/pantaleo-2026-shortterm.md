---
title: "Moment-to-Moment Pain Variability Predicts Pain Chronification"
authors: ["Gaia Pantaleo", "Carl Ashworth", "Maeghal Jain", "Flavia Mancini"]
year: 2026
venue: "bioRxiv"
doi: "10.64898/2026.03.02.709010"
url: "https://www.biorxiv.org/content/early/2026/05/15/2026.03.02.709010"
eprint: "https://www.biorxiv.org/content/early/2026/05/15/2026.03.02.709010.full.pdf"
publisher: "Cold Spring Harbor Laboratory"
elocation-id: "2026.03.02.709010"
---
G. Pantaleo and C. Ashworth contributed equally.

Moment-to-moment fluctuations in perceived pain are often dismissed as noise. However, across neural systems, rapid variability reflects fundamental network properties such as stability and flexibility, and in pain, reduced variability has been linked to chronic pain severity. Here, we tested whether alterations in such variability mark an early mechanistic transition from subacute to chronic pain. Using a longitudinal dataset of 120 individuals with subacute back pain followed over one year, we analysed continuous pain ratings alongside fMRI activity during spontaneous pain.

We show that patients who develop persistent pain exhibit a marked decrease in moment-to-moment pain variability over the course of one year, in contrast to recovering individuals whose variability increases over time. Neural activity in thalamo–cortico–limbic and modulatory circuits associated with these fluctuations at pain onset predicts clinical outcomes one year later. Notably, similar predictive patterns are observed during the early post-onset, indicating that these neural signatures emerge early and remain stable during the initial phase of disease progression.

These findings indicate that early loss of dynamical flexibility is a hallmark of pain chronification and identify moment-to-moment variability as a clinically accessible marker of the system’s dynamical state.
