---
title: "tDCS modulation of visually-induced analgesia"
authors: ["Flavia Mancini", "N. Bolognini", "P. Haggard", "G. Vallar"]
year: 2012
venue: "Journal of Cognitive Neuroscience"
---
