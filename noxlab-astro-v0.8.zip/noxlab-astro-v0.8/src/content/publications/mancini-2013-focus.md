---
title: "Focus on pain in the blind"
authors: ["Flavia Mancini"]
year: 2013
venue: "Pain"
---
Commentary
