---
title: "Dissociable hormonal responses to symptoms and stress in anorexia and bulimia nervosa"
authors: ["M. L. Westwater", "Flavia Mancini", "J. Shapleske", "J. Serfontein", "M. Ernst", "H. Ziauddeen", "P. Fletcher"]
year: 2020
venue: "Psychological Medicine"
---
