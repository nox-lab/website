---
title: "Validating a measure of the precision of ascending signals in pain perception"
authors: ["Aadya Singh", "Roi Treister", "Christiana Charalambous", "Flavia Mancini", "Deborah Talmi"]
year: 2026
venue: "Quarterly Journal of Experimental Psychology"
url: "https://doi.org/10.1177/17470218251343863"
doi: "10.1177/17470218251343863"
---
Published online 2025-05-10
