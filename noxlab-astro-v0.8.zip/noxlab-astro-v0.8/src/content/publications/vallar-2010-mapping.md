---
title: "Mapping the neglect syndrome onto neurofunctional streams"
authors: ["G. Vallar", "Flavia Mancini"]
year: 2010
venue: "Perception, Action, and Consciousness: Sensorimotor Dynamics and Two Visual Systems"
---
