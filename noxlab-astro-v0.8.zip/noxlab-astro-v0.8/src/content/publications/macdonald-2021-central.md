---
title: "A central mechanism of analgesia in mice and humans lacking the sodium channel NaV1.7"
authors: ["Donald Iain MacDonald", "Shafaq Sikandar", "Jan Weiss", "Martina Pyrski", "Ana P. Luiz", "Queensta Millet", "Edward C. Emery", "Flavia Mancini", "Gian D. Iannetti", "Sascha R. A. Alles", "Manuel Arcangeletti", "Jing Zhao", "James J. Cox", "Robert M. Brownstone", "Frank Zufall", "John N. Wood"]
year: 2021
venue: "Neuron"
doi: "10.1016/j.neuron.2021.03.012"
---
