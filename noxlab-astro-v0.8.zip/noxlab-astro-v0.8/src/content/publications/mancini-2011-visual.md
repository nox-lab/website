---
title: "Visual distortion of body size modulates pain perception"
authors: ["Flavia Mancini", "M. R. Longo", "M. Kammers", "P. Haggard"]
year: 2011
venue: "Psychological Science"
---
