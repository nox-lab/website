---
title: "Perceptual learning to discriminate the intensity and spatial location of nociceptive stimuli"
authors: ["Flavia Mancini", "K. Dolgevica", "J. Steckelmacher", "P. Haggard", "K. Friston", "G. D. Iannetti"]
year: 2016
venue: "Scientific Reports"
---
