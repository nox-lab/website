---
title: "Subject-Specific Information Enhances Spatial Accuracy of High-Density Diffuse Optical Tomography"
authors: ["S. Srinivasan", "D. Acharya", "E. Butters", "L. Collins-Jones", "Flavia Mancini", "G. Bale"]
year: 2024
venue: "Frontiers in Neuroergonomics"
url: "https://doi.org/10.3389/fnrgo.2024.1283290"
doi: "10.3389/fnrgo.2024.1283290"
---
