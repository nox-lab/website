---
title: "Towards an Interpretable Functional Image-Based Classifier: Dimensionality Reduction of High-Density Diffuse Optical Tomography Data"
authors: ["S. Srinivasan", "E. Butters", "Flavia Mancini", "G. Bale"]
year: 2023
venue: "ACAIN 2023"
---
Best Paper Award
