---
title: "Cross-modal processing in the occipito-temporal cortex: a TMS study of the Müller-Lyer illusion"
authors: ["Flavia Mancini", "N. Bolognini", "E. Bricolo", "G. Vallar"]
year: 2011
venue: "Journal of Cognitive Neuroscience"
---
