---
title: "Perception: A motion after-effect for voluntary actions"
authors: ["Flavia Mancini", "P. Haggard"]
year: 2014
venue: "Current Biology"
---
