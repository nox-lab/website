---
title: "Poor perception of distance between two nociceptive stimuli"
authors: ["Flavia Mancini", "H. Steinitz", "J. Steckelmacker", "G. D. Iannetti", "P. Haggard"]
year: 2015
venue: "Cognition"
---
