---
title: "Linking pain and the body: Neural correlates of visually induced analgesia"
authors: ["M. R. Longo", "G. D. Iannetti", "Flavia Mancini", "J. Driver", "P. Haggard"]
year: 2012
venue: "Journal of Neuroscience"
---
