---
title: "A fovea for pain at the fingertips"
authors: ["Flavia Mancini", "C. F. Sambo", "J. D. Ramirez", "D. L. H. Bennett", "P. Haggard", "G. D. Iannetti"]
year: 2013
venue: "Current Biology"
---
