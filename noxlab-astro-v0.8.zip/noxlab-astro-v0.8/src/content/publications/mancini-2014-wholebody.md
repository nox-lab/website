---
title: "Whole-body mapping of spatial acuity for pain and touch"
authors: ["Flavia Mancini", "A. Bauleo", "J. Cole", "F. Lui", "C. A. Porro", "P. Haggard", "G. D. Iannetti"]
year: 2014
venue: "Annals of Neurology"
---
F. Mancini and A. Bauleo contributed equally
