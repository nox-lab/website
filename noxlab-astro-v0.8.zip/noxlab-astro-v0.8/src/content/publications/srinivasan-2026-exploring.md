---
title: "Exploring neural correlates of emotional and social listening with high-density diffuse optical tomography in the auditory cortex"
authors: ["S. Srinivasan", "E. Butters", "D. Acharya", "et al."]
year: 2026
venue: "Scientific Reports"
---
Author list abbreviated in source; includes F. Mancini and G. Bale
