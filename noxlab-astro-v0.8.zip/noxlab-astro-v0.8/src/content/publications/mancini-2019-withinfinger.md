---
title: "Within-finger maps of tactile and nociceptive input in the human parietal cortex"
authors: ["Flavia Mancini", "M. H. Lee", "G. D. Iannetti", "I. Tracey"]
year: 2019
venue: "bioRxiv"
url: "https://doi.org/10.1101/599167"
doi: "10.1101/599167"
---
