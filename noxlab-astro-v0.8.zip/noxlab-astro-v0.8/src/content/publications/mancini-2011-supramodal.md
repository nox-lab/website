---
title: "A supramodal representation of the body surface"
authors: ["Flavia Mancini", "M. R. Longo", "G. D. Iannetti", "P. Haggard"]
year: 2011
venue: "Neuropsychologia"
---
