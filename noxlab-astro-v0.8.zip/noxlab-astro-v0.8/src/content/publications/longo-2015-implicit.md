---
title: "Implicit body representations and tactile spatial remapping"
authors: ["M. R. Longo", "Flavia Mancini", "P. Haggard"]
year: 2015
venue: "Acta Psychologica"
---
