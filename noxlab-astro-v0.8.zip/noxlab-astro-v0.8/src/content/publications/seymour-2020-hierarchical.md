---
title: "Hierarchical models of pain: Inference, information-seeking, and adaptive control"
authors: ["B. Seymour", "Flavia Mancini"]
year: 2020
venue: "NeuroImage"
---
