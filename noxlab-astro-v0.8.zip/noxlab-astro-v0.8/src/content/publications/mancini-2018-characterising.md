---
title: "Characterising the short-term habituation of event-related evoked potentials"
authors: ["Flavia Mancini", "A. Pepe", "A. Bernacchia", "G. Di Stefano", "A. Mouraux", "G. D. Iannetti"]
year: 2018
venue: "eNeuro"
---
