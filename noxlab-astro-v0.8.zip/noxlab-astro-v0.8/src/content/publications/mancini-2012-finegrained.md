---
title: "Fine-grained maps of nociceptive input in primary somatosensory cortex"
authors: ["Flavia Mancini", "P. Haggard", "G. D. Iannetti", "M. R. Longo", "M. I. Sereno"]
year: 2012
venue: "Journal of Neuroscience"
---
F. Mancini and P. Haggard contributed equally
