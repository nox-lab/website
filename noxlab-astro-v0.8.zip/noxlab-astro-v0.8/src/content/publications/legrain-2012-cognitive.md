---
title: "Cognitive aspects of nociception and pain. Bridging neurophysiology and neuropsychology"
authors: ["V. Legrain", "Flavia Mancini", "C. F. Sambo", "D. M. Torta", "I. Ronga", "E. Valentini"]
year: 2012
venue: "Clinical Neurophysiology"
---
