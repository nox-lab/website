---
title: "Fine-grained mapping of cortical somatotopies in chronic Complex Regional Pain Syndrome"
authors: ["Flavia Mancini", "A. Wang", "M. Schira", "Z. J. Isherwood", "J. McAuley", "G. D. Iannetti", "M. I. Sereno", "L. Moseley", "C. D. Rae"]
year: 2019
venue: "Journal of Neuroscience"
---
