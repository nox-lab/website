---
title: "Endogenous opioids contribute to insensitivity to pain in humans and mice lacking sodium channel Nav1.7"
authors: ["M. S. Minett", "V. Pereira", "S. Sikandar", "A. Matsuyama", "S. Lolignier", "A. H. Kanellopoulos", "Flavia Mancini", "G. D. Iannetti", "Y. D. Bogdanov", "S. Santana-Varela", "Q. Millet", "G. Baskozos", "R. MacAllister", "J. J. Cox", "J. Zhao", "J. N. Wood"]
year: 2015
venue: "Nature Communications"
---
