---
title: "Statistical learning shapes pain perception and prediction independently of external cues"
authors: ["Jakub Onysk", "Nicholas Gregory", "Mia Whitefield", "Maeghal Jain", "Georgia Turner", "Ben Seymour", "Flavia Mancini"]
year: 2023
venue: "eLife"
url: "https://doi.org/10.7554/eLife.90634.1"
doi: "10.7554/eLife.90634.1"
---
