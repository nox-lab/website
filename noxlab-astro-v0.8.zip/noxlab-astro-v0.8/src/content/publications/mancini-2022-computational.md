---
title: "Computational and neural mechanisms of statistical pain learning"
authors: ["Flavia Mancini", "S. Zhang", "B. Seymour"]
year: 2022
venue: "Nature Communications"
doi: "10.1038/s41467-022-34283-9"
---
