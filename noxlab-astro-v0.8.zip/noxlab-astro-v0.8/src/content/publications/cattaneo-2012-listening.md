---
title: "Listening to numbers affects visual and haptic bisection in healthy individuals and neglect patients"
authors: ["Z. Cattaneo", "M. Fantino", "Flavia Mancini", "F. C. Mattioli", "G. Vallar"]
year: 2012
venue: "Neuropsychologia"
---
