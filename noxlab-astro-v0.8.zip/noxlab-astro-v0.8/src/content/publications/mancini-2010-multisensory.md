---
title: "Multisensory integration in the Müller-Lyer illusion: From vision to haptics"
authors: ["Flavia Mancini", "E. Bricolo", "G. Vallar"]
year: 2010
venue: "Quarterly Journal of Experimental Psychology"
url: "https://pubmed.ncbi.nlm.nih.gov/19728224/"
---
