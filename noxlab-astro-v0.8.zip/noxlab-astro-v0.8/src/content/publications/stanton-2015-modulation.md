---
title: "Modulation of pain via expectation of its location"
authors: ["T. Stanton", "H. Gilpin", "E. Reid", "Flavia Mancini", "C. Spence", "L. G. Moseley"]
year: 2015
venue: "European Journal of Pain"
doi: "10.1002/ejp.801"
---
