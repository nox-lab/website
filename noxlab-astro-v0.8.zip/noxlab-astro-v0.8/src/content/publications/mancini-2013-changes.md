---
title: "Changes in cortical oscillations linked to multisensory modulation of nociception"
authors: ["Flavia Mancini", "M. R. Longo", "E. Canzoneri", "G. Vallar", "P. Haggard"]
year: 2013
venue: "European Journal of Neuroscience"
---
