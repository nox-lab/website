---
title: "Neuromodulation of Multisensory Perception: a tDCS study of the sound-induced flash illusion"
authors: ["N. Bolognini", "A. Rossetti", "C. Casati", "Flavia Mancini", "G. Vallar"]
year: 2011
venue: "Neuropsychologia"
---
