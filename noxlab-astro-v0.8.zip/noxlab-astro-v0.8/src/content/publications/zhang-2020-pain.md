---
title: "Pain Control by Co-adaptive Learning in a Brain-Machine Interface"
authors: ["S. Zhang", "W. Yoshida", "H. Mano", "T. Yanagisawa", "Flavia Mancini", "K. Shibata", "M. Kawato", "B. Seymour"]
year: 2020
venue: "Current Biology"
---
