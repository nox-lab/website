---
title: "Prefrontal responses during proactive and reactive inhibition are differentially impacted by stress in anorexia and bulimia nervosa"
authors: ["M. L. Westwater", "Flavia Mancini", "A. Gorka", "J. Shapleske", "J. Serfontein", "C. Grillon", "M. Ernst", "H. Ziauddeen", "P. Fletcher"]
year: 2021
venue: "Journal of Neuroscience"
---
