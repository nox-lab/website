---
title: "Multisensory integration in hemianopia and unilateral spatial neglect: Evidence from the sound induced flash illusion"
authors: ["N. Bolognini", "S. Convento", "C. Casati", "Flavia Mancini", "F. Brighina", "G. Vallar"]
year: 2016
venue: "Neuropsychologia"
---
