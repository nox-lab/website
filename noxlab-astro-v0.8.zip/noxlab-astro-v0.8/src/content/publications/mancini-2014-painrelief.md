---
title: "Pain relief by touch: A quantitative approach"
authors: ["Flavia Mancini", "T. Nash", "G. D. Iannetti", "P. Haggard"]
year: 2014
venue: "Pain"
---
