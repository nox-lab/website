---
title: "Visuo-haptic interactions in unilateral spatial neglect: the crossmodal Judd illusion"
authors: ["Flavia Mancini", "E. Bricolo", "F. C. Mattioli", "G. Vallar"]
year: 2011
venue: "Frontiers in Psychology"
doi: "10.3389/fpsyg.2011.00341"
---
