---
title: "Short-term variability of chronic musculoskeletal pain"
authors: ["X. Zheng", "S. Rajwal", "Carl Ashworth", "S. Y. S. Ho", "B. Seymour", "N. Shenker", "Flavia Mancini"]
year: 2025
venue: "Frontiers in Pain Research"
url: "https://doi.org/10.3389/fpain.2025.1626589"
doi: "10.3389/fpain.2025.1626589"
---
