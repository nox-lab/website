---
title: "Subcortical and neocortical mechanisms of visual-somatosensory interplay"
authors: ["Flavia Mancini"]
year: 2013
venue: "Journal of Neuroscience"
---
