---
title: "Confidence of probabilistic predictions modulates the cortical response to pain"
authors: ["D. Mulders", "B. Seymour", "A. Mouraux", "Flavia Mancini"]
year: 2023
venue: "Proceedings of the National Academy of Sciences"
doi: "10.1073/pnas.2212252120"
---
