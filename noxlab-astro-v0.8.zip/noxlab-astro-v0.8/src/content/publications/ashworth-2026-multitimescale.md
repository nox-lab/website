---
title: "Multi-timescale dynamics organize descending pain modulation"
authors: ["Carl Ashworth", "Melissa Martenson", "Zhigang Shi", "Caitlynn C De Preter", "Mary Heinricher", "Flavia Mancini"]
year: 2026
month: Aug
venue: "eLife"
publisher: "eLife Sciences Publications, Ltd"
url: "https://doi.org/10.7554/eLife.112259.1"
doi: "10.7554/eLife.112259.1"
---
