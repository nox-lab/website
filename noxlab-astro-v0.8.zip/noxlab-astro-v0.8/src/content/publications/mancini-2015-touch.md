---
title: "Touch inhibits subcortical and cortical nociceptive responses"
authors: ["Flavia Mancini", "A. L. Beaumont", "L. Hu", "P. Haggard", "G. D. Iannetti"]
year: 2015
venue: "Pain"
---
