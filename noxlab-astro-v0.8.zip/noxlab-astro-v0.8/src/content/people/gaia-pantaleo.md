---
name: Gaia Pantaleo
role: PhD Researcher
group: phd
linkedin: https://www.linkedin.com/in/gaia-pantaleo-95771b22a/
email: gp565@cam.ac.uk
photoAlt: Portrait of Gaia Pantaleo
photo: /images/people/gaia-pantaleo.jpg
order: 5
research: ["Statistical learning", "Pain", "Decision-making"]
---
Gaia studies how statistical learning shapes pain perception and endogenous regulation, and how these processes may malfunction in chronic pain.
