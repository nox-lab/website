---
name: Benjamin Slater
role: PhD Researcher
group: phd
linkedin: https://www.linkedin.com/in/benjamin-slater-341963185/
email: bas58@cam.ac.uk
photo: https://www.noxlab.org/wp-content/uploads/2024/01/558a8106-300x290.jpg
photoAlt: Portrait of Benjamin Slater
order: 4
research: ["Artificial agents", "Capability assessment", "Animal AI"]
---
Benjamin develops methods for assessing the capabilities of artificial agents as part of the Animal AI project.
