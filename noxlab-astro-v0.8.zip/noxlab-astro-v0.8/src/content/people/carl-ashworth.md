---
name: Carl Ashworth
role: PhD Researcher
group: phd
linkedin: https://www.linkedin.com/in/carlashworth/
email: ca541@cam.ac.uk
photoAlt: Portrait of Carl Ashworth
photo: /images/people/carl-ashworth.jpg
order: 2
research: ["Control theory", "Pain regulation", "Homeostasis"]
---
Carl studies the neural mechanisms involved in body homeostasis and endogenous pain regulation from a theoretical and control-theoretic perspective.
