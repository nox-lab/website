---
name: Qingyun Chen
role: PhD Researcher
group: phd
email: qc248@cam.ac.uk
photoAlt: Portrait of Qingyun Chen
photo: /images/people/qingyun-chen.jpg
order: 3
research: ["Pain regulation", "Brainstem modelling"]
---
Qingyun develops models of pain-regulation loops, with a particular interest in the periaqueductal grey and related brainstem systems.
