---
name: Flavia Mancini
role: Head of NOX Lab
group: leadership
linkedin: https://www.linkedin.com/in/flavia-mancini-468328181/
photo: /images/people/flavia-mancini.jpg
order: 1
email: flavia.mancini@eng.cam.ac.uk
orcid: https://orcid.org/0000-0001-8441-9236
scholar: https://scholar.google.com/citations?user=eFt4-cwAAAAJ&hl=en
research: ["Computational neuroscience", "Pain", "Learning", "Neurotechnology"]
---

Flavia is Professor of Computational Neuroscience and an MRC Career Development Award Fellow in the [Department of Engineering](https://www.eng.cam.ac.uk/) at the University of Cambridge. She trained in neuroscience at the University of Milan, University College London and the University of Cambridge, and is a Fellow of Pembroke College, Cambridge.

She co-directs the Biological Learning track of the [Machine Learning and Machine Intelligence MPhil](https://www.mlmi.eng.cam.ac.uk/). She has received over £14 million in research funding as lead or co-lead, primarily from UKRI’s EPSRC and MRC. Her research has featured in The Guardian, The New York Times, Financial Times, The Washington Post and New Scientist, and on the BBC.
