---
title: "Neurotechnology"
shortTitle: "Neurotechnology"
kind: core
summary: "Developing model-informed, adaptive neurotechnologies for measuring, interpreting and influencing nervous-system function."
order: 2
---

Neurotechnology increasingly depends on computational models capable of interpreting complex neural dynamics. We develop computational approaches that enable adaptive technologies for measuring, predicting and influencing nervous-system function. Our starting point is the biological system: what can be inferred about its state, how that state changes over time, and how an intervention might alter its dynamics.

This connects fundamental neuroscience with computational neuroengineering. A neural signal becomes useful for adaptive technology when it can be interpreted in relation to a mechanism or function. We develop models and analytical methods that support this interpretation, including computational biomarkers that describe relevant aspects of nervous-system dynamics. These measures are intended to link observations to testable accounts of the processes they reflect, rather than treating a predictive signal as a complete explanation.

Closed-loop systems make this relationship between measurement and intervention particularly important. They use ongoing observations to update an intervention as the system changes. Computational models can help determine which signals are informative, what changes an intervention is expected to produce, and how feedback should shape subsequent decisions. We are interested in how such systems can accommodate variability between individuals and within the same individual over time.

### EPIONE: theory informing adaptive neurotechnology

Professor Flavia Mancini is the theory lead for **EPIONE—Effective Pain Interventions with Neural Engineering**. NOX Lab leads the theoretical and computational framework within the programme, developing models of pain regulation and neural dynamics to inform adaptive sensing and intervention. This leadership places computational theory at the centre of the connection between biological mechanisms and engineering design.

EPIONE is an interdisciplinary programme developing engineering approaches to chronic pain. Its research brings together sensing, interventions that modulate brain activity, computational models and adaptive control. Our contribution asks how models of the nervous system can guide the interpretation of measurements and the design of interventions, providing a quantitative basis for investigating when and how a system should respond.

Pain is a concrete setting in which to develop these ideas, while the computational questions extend across neurotechnology. How can a model remain useful when observations are incomplete? Which aspects of neural dynamics need to be represented to guide an intervention? How can a system adapt without losing a clear account of why it acts? These questions connect our technology research to the broader aim of understanding nervous-system regulation.

[Learn more about EPIONE →](https://eng.ox.ac.uk/epione)
