---
title: "Sensorimotor & Defensive Systems"
shortTitle: "Sensorimotor & Defensive Systems"
kind: core
summary: "Understanding sensory processing, sensorimotor control, pain, homeostatic regulation and adaptive behaviour across biological scales."
order: 3
---

Nervous systems continually coordinate information about the body and the environment with the demands of action. We study how sensory processing, sensorimotor control and defensive regulation work together to support adaptive behaviour. This includes how organisms respond to changing conditions, learn from experience and maintain physiological stability while pursuing different goals.

Sensorimotor function is an active process. Movements change the sensory information available to the nervous system, while incoming signals guide subsequent actions. Understanding this interaction requires considering both the processing of sensory input and the mechanisms that regulate its influence on behaviour. We investigate these relationships across biological scales, connecting the activity of sensory neurons and circuits with the organisation of behaviour.

Defensive systems are an important part of this broader programme. They coordinate responses to potentially harmful events and help protect the body. Their function depends on context: a response that is useful in one situation may be unnecessary or disruptive in another. We ask how nervous systems regulate this balance, how experience changes protective behaviour, and how defensive responses interact with ongoing sensorimotor demands.

Pain provides one model for studying these principles. It allows us to investigate how sensory evidence, prior experience and physiological state shape perception and action. Persistent pain raises questions about how regulatory processes become sustained or poorly matched to current conditions. These questions sit within a wider investigation of adaptive regulation; they do not define the full scope of our sensory and sensorimotor research.

Homeostasis is another central thread. Organisms must respond to external events while regulating their internal state. We are interested in how these demands are coordinated, and how neural dynamics support both stability and flexibility. Learning and adaptation connect these processes over time, allowing behaviour to change as the environment, the body and the consequences of action change.

By linking these biological questions to computational theory, we seek to explain how sensory information is selected, transformed and used to regulate behaviour. Our aim is to understand the shared principles that organise perception, action and physiological regulation, as well as the mechanisms that give each system its particular function.
